<?php

session_start();

 if(!isset($_SESSION['usuario'])){
     echo'
        <script>
            alert("por favor debes iniciar secion");
        </script>
     ';
   header("location: index.php");
   session_destroy(); 
   die();
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu con subemenu</title>
    <script src="https://kit.fontawesome.com/41bcea2ae3.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="estilos/estilos.css">
</head>
<body>
    
    <header>
        <div class="header__superior">
            <div class="logo">
                <img src="img/andrea_store.jpeg" alt="">
            </div>
            <div class="search">
                <input type="search" placeholder="¿Qué deseas buscar?">
            </div>
        </div>

        <div class="container__menu">

            <div class="menu">
                <input type="checkbox" id="check__menu">
                <label for="check__menu" id="label__check">
                    <i class="fas fa-bars icon__menu"></i>
                </label>
                <nav>
                    <ul>
                        <li><a href="#" id="selected"></a></li>
                        <li><a href="../nuevosistemaproyecto/casillas/lista_de_producto.php">Lista De Producto</a></li>
                        <li><a href="../nuevosistemaproyecto/casillas/lista_de_compras_y_ventas.php">Ventas Y Compras</a></li>
                        <li><a href="../nuevosistemaproyecto/casillas/facturas.php">Facturas</a></li>
                        <li><a href="#">Configuracion</a>
                        <ul>
                                <li><a href="../nuevosistemaproyecto/casillas/perfil_usuario.php">perfil del usuario</a></li>
                                <li><a href="#">salir de sistema </a></li>
                            </ul>
                       </li>
                       
                    </ul>
                </nav>
            </div>

        </div>

    </header>

     
</body>
</html>