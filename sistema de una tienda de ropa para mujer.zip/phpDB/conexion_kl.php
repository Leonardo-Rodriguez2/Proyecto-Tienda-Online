<?php

   $conexion = mysqli_connect ("localhost", "root", "", "proyectokl" );

   /*
   if($conexion){
     echo ' conectado exitosamente';
   }else{
    echo ' no esta conectada a la Base de Datos';
   } 
    */
?>