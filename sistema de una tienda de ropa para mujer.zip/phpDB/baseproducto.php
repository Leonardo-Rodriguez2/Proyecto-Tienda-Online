<?php
/*
include 'conexion_kl.php';

$codigo = $_POST['codigo'];
$producto = $_POST['producto'];
$precio_compra = $_POST['precio_compra'];
$precio_venta = $_POST['precio_venta'];
$cantidad = $_POST['cantidad'];

$query = "INSERT INTO productos(codigo, producto, precio_compra, precio_venta, cantidad)
          VALUES ('$codigo' , '$producto' , '$precio_compra' , '$precio_venta' , '$cantidad')";

  $ejecutar = mysqli_query($conexion , $query);        
  
  if($ejecutar){
    echo '
          <script>
                 alert("producto almacenado exitosamente");
                 window.location = "../casillas/lista_de_producto.php";  
          </script>   
    ';
   }else{
    echo '
          <script>
                 alert("intentelo de nuevo, producto no almacenado");
                 window.location = "../casillas/lista_de_producto.php";  
    <    </script>   
    ';
   }
  
   mysqli_close($conexion);
*/
?>